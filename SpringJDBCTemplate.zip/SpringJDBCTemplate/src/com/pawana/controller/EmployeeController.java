package com.pawana.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import com.pawana.model.Employee;
import com.pawana.service.EmployeeService;

@Controller
public class EmployeeController {
	@Autowired
	private EmployeeService service;
	
	
	
	public void setService(EmployeeService service) {
		this.service = service;
	}



	public String saveEmployee(Employee emp) {
		return service.saveEmployee(emp);
	}
}
