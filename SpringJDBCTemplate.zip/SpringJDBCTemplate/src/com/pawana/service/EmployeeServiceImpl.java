package com.pawana.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pawana.dao.EmployeeDAO;
import com.pawana.model.Employee;

@Service
public class EmployeeServiceImpl implements EmployeeService {
	
	@Autowired
	private EmployeeDAO dao;
	
	

	public void setDao(EmployeeDAO dao) {
		this.dao = dao;
	}



	@Override
	public String saveEmployee(Employee emp) {
		int res=dao.saveEmployee(emp);
		if(res==1) {
			return "Employee insertion successful";
		}else
			return "Employee Insertion failed";
	}

}
