package com.pawana.service;

import com.pawana.model.Employee;

public interface EmployeeService {
	public String saveEmployee(Employee emp);
}
