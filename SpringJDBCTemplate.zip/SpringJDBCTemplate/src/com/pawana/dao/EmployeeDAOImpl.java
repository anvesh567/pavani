package com.pawana.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.pawana.model.Employee;

@Repository
public class EmployeeDAOImpl implements EmployeeDAO {
	
	@Autowired
	private JdbcTemplate jt;
	
	
	
	
	  public void setJt(JdbcTemplate jt) { this.jt = jt; }
	 


	@Override
	public int saveEmployee(Employee emp) {
		
		return jt.update("insert into employee values(?,?,?)",emp.getEid(),emp.getEname(),emp.getSal());

	}

}
