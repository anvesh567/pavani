package com.pawana.dao;

import com.pawana.model.Employee;

public interface EmployeeDAO {
	public int saveEmployee(Employee emp);
}
