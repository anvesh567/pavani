package com.pawana.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

import com.pawana.controller.EmployeeController;
import com.pawana.model.Employee;

public class JdbcTemplateTest {

	public static void main(String[] args) {
		ApplicationContext ctx=new FileSystemXmlApplicationContext("src/com/pawana/cfgs/Applicationcontext.xml");
		
		EmployeeController controller=ctx.getBean("controller",EmployeeController.class);
		
		Employee emp=new Employee();
		emp.setEid(15);
		emp.setEname("Institute");
		emp.setSal(46000);
		
		System.out.println(controller.saveEmployee(emp));
	}

}
